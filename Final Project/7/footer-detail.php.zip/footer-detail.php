<!--<div id="worka">
				<div class="mix block-grid designdigital" data-value="1"><div class="grid-gutter"><a href='works/cafe-del-mondo-outdoor'><img src='../../images/cafedelmondo01.jpg' class="work-image desaturate"></a></div></div>
				<div class="mix block-grid film" data-value="2"><div class="grid-gutter"><a href='works/cafe-del-mondo-press'><img src='../../images/cafedelmondo02.jpg'  class="work-image"></a></div></div>
				<div class="mix block-grid printoutdoor" data-value="3"><div class="grid-gutter"><a href='works/cares'><img src='../../images/ceres.jpg'  class="work-image"></a></div></div>
				<div class="mix block-grid personal" data-value="4"><div class="grid-gutter"><a href='works/cnn'><img src='../../images/cnn.jpg' class="work-image" ></a></div></div>
				<div class="mix block-grid designdigital" data-value="5"><div class="grid-gutter"><a href='works/cornetto'><img src='../../images/cornetto.jpg' class="work-image"></a></div></div>
				<div class="mix block-grid film" data-value="6"><div class="grid-gutter"><a href='works/cares'><img src='../../images/finansbank01.jpg' class="work-image"></a></div></div>
				<div class="mix block-grid printoutdoor" data-value="7"><div class="grid-gutter"><a href='works/finansbank-2'><img src='../../images/finansbank02.jpg' class="work-image" ></a></div></div>
				<div class="mix block-grid designdigital" data-value="8"><div class="grid-gutter"><a href='works/gursoy'><img src='../../images/gursoy.jpg'   class="work-image"></a></div></div>
				<div class="mix block-grid personal" data-value="9"><div class="grid-gutter"><a href='works/hepsi'><img src='../../images/hepsi.jpg'   class="work-image"></a></div></div>
				<div class="mix block-grid printoutdoor" data-value="10"><div class="grid-gutter"><a href='works/kasap'><img src='../../images/kasap.jpg'  class="work-image" ></a></div></div>
				<div class="mix block-grid designdigital"><div class="grid-gutter"><a href='works/lassa'><img src='../../images/lassa.jpg'   class="work-image"></a></div></div>
				<div class="mix block-grid film"><div class="grid-gutter"><a href='works/magnum'><img src='../../images/magnum.jpg'   class="work-image"></a></div></div>
				<div class="mix block-grid designdigital"><div class="grid-gutter"><a href='works/persil'><img src='../../images/persil.jpg'   class="work-image"></a></div></div>
				<div class="mix block-grid film"><div class="grid-gutter"><a href='works/sok'><img src='../../images/sok.jpg'   class="work-image"></a></div></div>
				<div class="mix block-grid personal"><div class="grid-gutter"><a href='works/wwf'><img src='../../images/wwf.jpg'   class="work-image"></a></div></div>
			</div>

-->
<div id="worka">
				<div class="mix block-grid printoutdoor" data-value="1"><div class="grid-gutter"><a href='works/cafe-del-mondo-outdoor'><img src='../../images/cafedelmondo01.jpg' class="work-image desaturate"><span>Outdoor - CAFE DEL MONDO</span></a></div></div>
				<div class="mix block-grid printoutdoor" data-value="2"><div class="grid-gutter"><a href='works/cafe-del-mondo-press'><img src='../../images/cafedelmondo02.jpg'  class="work-image desaturate"><span>Press - CAFE DEL MONDO</span></a></div></div>
				<div class="mix block-grid printoutdoor" data-value="3"><div class="grid-gutter"><a href='works/cares'><img src='../../images/ceres.jpg'  class="work-image desaturate"><span>Press - Ceres</span></a></div></div>
				<div class="mix block-grid printoutdoor" data-value="4"><div class="grid-gutter"><a href='works/cnn'><img src='../../images/cnn.jpg' class="work-image desaturate" ><span>Outdoor- CNN</span></a></div></div>
				<div class="mix block-grid film" data-value="5"><div class="grid-gutter"><a href='works/cornetto'><img src='../../images/cornetto.jpg' class="work-image desaturate"><span>TV - Cornetto</span></a></div></div>
				<div class="mix block-grid film" data-value="6"><div class="grid-gutter"><a href='works/finansbank'><img src='../../images/finansbank01.jpg' class="work-image desaturate"><span>TV - Finansbank</span></a></div></div>
				<div class="mix block-grid film" data-value="7"><div class="grid-gutter"><a href='works/finansbank-2'><img src='../../images/finansbank02.jpg' class="work-image desaturate" ><span>TV - Finansbank</span></a></div></div>
				<div class="mix block-grid printoutdoor" data-value="8"><div class="grid-gutter"><a href='works/gursoy'><img src='../../images/gursoy.jpg'   class="work-image desaturate"><span>Outdoor - Gursoy Art School</span></a></div></div>
				<div class="mix block-grid printoutdoor" data-value="9"><div class="grid-gutter"><a href='works/hepsi'><img src='../../images/hepsi.jpg'   class="work-image desaturate"><span>Outdoor - hepsiburada.com</span></a></div></div>
				<div class="mix block-grid film" data-value="10"><div class="grid-gutter"><a href='works/kasap'><img src='../../images/kasap.jpg'  class="work-image desaturate" ><span>Tv - KasapDoner</span></a></div></div>
				<div class="mix block-grid printoutdoor"><div class="grid-gutter"><a href='works/lassa'><img src='../../images/lassa.jpg'   class="work-image desaturate"><span>Press - Lassa Tyres</span></a></div></div>
				<div class="mix block-grid film"><div class="grid-gutter"><a href='works/magnum'><img src='../../images/magnum.jpg'   class="work-image desaturate"><span>TV - Magnum</span></a></div></div>
				<div class="mix block-grid printoutdoor"><div class="grid-gutter"><a href='works/persil'><img src='../../images/persil.jpg'   class="work-image desaturate"><span>Poster - Persil</span></a></div></div>
				<div class="mix block-grid printoutdoor"><div class="grid-gutter"><a href='works/sok'><img src='../../images/sok.jpg'   class="work-image desaturate"><span>Outdoor - SOK Supermarkets</span></a></div></div>
				<div class="mix block-grid printoutdoor"><div class="grid-gutter"><a href='works/wwf'><img src='../../images/wwf.jpg'   class="work-image desaturate"><span>Outdoor - WWF</span></a></div></div>
				<div class="mix block-grid printoutdoor"><div class="grid-gutter"><a href='works/finansbank-press'><img src='../../images/finansbank03.jpg'   class="work-image desaturate"><span>Press - Finansbank</span></a></div></div>
			</div>


			<script>
    $(document).ready(function() {
       // $('.fancybox').fancybox();

$(".fancybox").fancybox({
    helpers : {
        overlay : {
            locked : false
        }
    }
});


    });
</script>